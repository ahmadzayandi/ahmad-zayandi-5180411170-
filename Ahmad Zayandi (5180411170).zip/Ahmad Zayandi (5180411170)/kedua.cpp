#include <iostream>
using namespace std;
int main (){

int h,j;
h = 125;
do {
	
	cout<<h<<",";
	h = h + 5;
	
}
while (h<=200);
}
