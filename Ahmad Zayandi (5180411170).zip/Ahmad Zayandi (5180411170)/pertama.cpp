#include <iostream>
using namespace std;
int main (){

int a  ;
a = 125;
while (a<=200){
	
	cout<<a<<",";
	a = a + 5;
	
}
}
